const http = require("http");
const { Telegraf } = require("telegraf");
const { delivery } = require("./functions/delivery");
const { startFunction } = require("./functions/start");

const hostname = "127.0.0.1";
const port = 3000;
const bot = new Telegraf("5517715308:AAH1ypIeonFsPcs-bAzG3o-nAOAqk4OrA34");

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/plain");
  res.end("Hello Xami Xane");
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

startFunction();
//Search action method
delivery();

bot.launch();
